from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash
)

from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import csv
import io
import zipfile
import hmac
import secrets
import os
import time
from pathlib import Path
from flask import jsonify, send_file

from config import (
    SECRET_KEY,
    CTF_DURATION,
    HARD_UNLOCK_SECONDS,
    EASY_UNLOCK_SECONDS,
    MODERATE_UNLOCK_SECONDS
)

from database import get_db, init_db

from auth import (
    create_user,
    authenticate
)

from challenges import CHALLENGES


app = Flask(__name__)

app.secret_key = SECRET_KEY

# Store timestamps in UTC for reliable ordering; display them in Indian Standard Time.
INDIA_TZ = ZoneInfo("Asia/Kolkata")
def india_time(value, fmt="%d-%m-%Y %H:%M:%S IST"):
    if not value:
        return "—"
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.astimezone(INDIA_TZ).strftime(fmt)
    except (ValueError, TypeError):
        return str(value)

app.jinja_env.filters["india_time"] = india_time
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = __import__("os").environ.get("CTF_HTTPS", "0") == "1"
app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024

@app.before_request
def protect_post_requests():
    if request.method == "POST":
        expected = session.get("csrf_token", "")
        supplied = request.form.get("csrf_token", "")
        if not expected or not supplied or not hmac.compare_digest(expected, supplied):
            return "Invalid or expired form token. Reload the page and try again.", 400

@app.context_processor
def csrf_template_value():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return {"csrf_token": session["csrf_token"]}


# --------------------------------------------------
# DATABASE
# --------------------------------------------------

init_db()


def event_config():
    db = get_db()
    row = db.execute("SELECT * FROM event WHERE id = 1").fetchone()
    db.close()
    return row


def event_status():
    row = event_config()
    return row["status"] if row else "not_started"


def is_event_running():
    row = event_config()
    return bool(row and row["status"] == "running")


# --------------------------------------------------
# USER
# --------------------------------------------------

def current_user():

    if "user_id" not in session:
        return None

    db = get_db()

    user = db.execute(
        """
        SELECT *
        FROM users
        WHERE id = ?
        """,
        (session["user_id"],)
    ).fetchone()

    db.close()

    if user and user["disqualified"]:
        session.clear()
        return None

    return user


# --------------------------------------------------
# EVENT TIME
# --------------------------------------------------

def get_start_time():

    db = get_db()

    event = db.execute(
        """
        SELECT started_at
        FROM event
        WHERE id = 1
        """
    ).fetchone()

    db.close()

    if not event:
        return None

    if not event["started_at"]:
        return None

    return datetime.fromisoformat(
        event["started_at"]
    )


def elapsed_seconds():

    started = get_start_time()

    if not started:
        return 0

    now = datetime.now(timezone.utc)

    return max(
        0,
        int(
            (now - started).total_seconds()
        )
    )


def event_started():

    return get_start_time() is not None


def participant_elapsed_seconds(user=None):
    user = user or current_user()
    if not user or not user["joined_at"]:
        return 0
    try:
        joined = datetime.fromisoformat(user["joined_at"])
        if joined.tzinfo is None:
            joined = joined.replace(tzinfo=timezone.utc)
        return max(0, int((datetime.now(timezone.utc) - joined).total_seconds()))
    except (ValueError, TypeError):
        return 0


def easy_unlocked():
    # All rounds are available immediately; there is no per-round waiting period.
    return True


def moderate_unlocked():
    return True


def event_finished():

    cfg = event_config()
    return bool(cfg and cfg["status"] == "ended") or elapsed_seconds() >= (cfg["duration_seconds"] if cfg else CTF_DURATION)


def hard_unlocked():
    return True


# --------------------------------------------------
# TEMPLATE VARIABLES
# --------------------------------------------------

@app.context_processor
def template_variables():

    return {

        "event_started":
            event_started(),

        "event_finished":
            event_finished(),

        "elapsed":
            elapsed_seconds(),

        "duration":
            (event_config()["duration_seconds"] if event_config() else CTF_DURATION),

        "easy_unlocked": easy_unlocked(),
        "moderate_unlocked": moderate_unlocked(),

        "hard_unlocked":
            hard_unlocked(),

        "hard_unlock_seconds":
            HARD_UNLOCK_SECONDS,

        "viewer":
            current_user(),
        "event_status": event_status()
    }


# --------------------------------------------------
# HOME
# --------------------------------------------------

@app.route("/")
def home():

    if "user_id" not in session:
        return redirect(
            url_for("login")
        )

    return redirect(
        url_for("dashboard")
    )


# --------------------------------------------------
# REGISTER
# --------------------------------------------------

@app.route("/register", methods=["GET", "POST"])
def register():
    # Public self-registration is disabled; administrators provision accounts.
    flash("Registration is closed. Contact the event administrator for credentials.")
    return redirect(url_for("login"))


# --------------------------------------------------
# LOGIN
# --------------------------------------------------

def request_ip_key():
    # Do not trust forwarded headers unless the reverse proxy is configured to sanitize them.
    return request.remote_addr or "unknown"


def login_is_rate_limited(ip_key):
    now = datetime.now(timezone.utc)
    db = get_db()
    row = db.execute("SELECT * FROM login_rate_limits WHERE ip_key = ?", (ip_key,)).fetchone()
    if row and row["blocked_until"]:
        try:
            if datetime.fromisoformat(row["blocked_until"]) > now:
                db.close(); return True
        except ValueError:
            pass
    db.close()
    return False


@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":
        ip_key = request_ip_key()
        if login_is_rate_limited(ip_key):
            flash("Too many login attempts. Please wait 10 minutes before trying again.")
            return redirect(url_for("login"))

        username = request.form.get(
            "username",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        )

        user = authenticate(
            username,
            password
        )

        db = get_db()
        db.execute(
            "INSERT INTO login_events(username_attempted, user_id, success, attempted_at) VALUES (?, ?, ?, ?)",
            (username[:64], user["id"] if user else None, int(bool(user and not user["disqualified"])), datetime.now(timezone.utc).isoformat()),
        )
        now_dt = datetime.now(timezone.utc)
        limit = db.execute("SELECT * FROM login_rate_limits WHERE ip_key = ?", (ip_key,)).fetchone()
        if user and not user["disqualified"]:
            db.execute("DELETE FROM login_rate_limits WHERE ip_key = ?", (ip_key,))
        else:
            if not limit or (now_dt - datetime.fromisoformat(limit["window_started_at"])).total_seconds() > 600:
                db.execute("INSERT INTO login_rate_limits(ip_key, window_started_at, attempts, blocked_until) VALUES (?, ?, 1, NULL) ON CONFLICT(ip_key) DO UPDATE SET window_started_at=excluded.window_started_at, attempts=1, blocked_until=NULL", (ip_key, now_dt.isoformat()))
                attempts = 1
            else:
                attempts = int(limit["attempts"]) + 1
                blocked = (now_dt + __import__("datetime").timedelta(minutes=10)).isoformat() if attempts >= 5 else None
                db.execute("UPDATE login_rate_limits SET attempts=?, blocked_until=COALESCE(?, blocked_until) WHERE ip_key=?", (attempts, blocked, ip_key))
            if attempts >= 5:
                db.execute("INSERT INTO security_alerts(alert_type, severity, details, created_at) VALUES ('login_bruteforce', 'high', ?, ?)", (f"5+ failed login attempts from IP key {ip_key}", now_dt.isoformat()))
        db.commit()
        db.close()

        if not user:
            flash("Invalid username or password.")
            return redirect(url_for("login"))

        if user["disqualified"]:
            flash("This account has been disqualified. Contact the administrator.")
            return redirect(url_for("login"))

        db = get_db()
        now = datetime.now(timezone.utc).isoformat()
        db.execute("UPDATE users SET joined_at = COALESCE(joined_at, ?), last_login_at = ?, login_count = login_count + 1 WHERE id = ?",
                   (now, now, user["id"]))
        db.execute("INSERT INTO audit_log(actor_user_id, action, details, created_at) VALUES (?, 'login_success', 'Successful login', ?)", (user["id"], now))
        db.commit()
        db.close()

        session.clear()
        session["user_id"] = user["id"]

        return redirect(
            url_for("dashboard")
        )

    return render_template(
        "login.html"
    )


# --------------------------------------------------
# LOGOUT
# --------------------------------------------------

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("login")
    )


# --------------------------------------------------
# DASHBOARD
# --------------------------------------------------

@app.route("/dashboard")
def dashboard():

    user = current_user()

    if not user:

        return redirect(
            url_for("login")
        )

    db = get_db()

    solved_rows = db.execute(
        """
        SELECT challenge_id
        FROM submissions

        WHERE user_id = ?
        AND correct = 1
        """,
        (user["id"],)
    ).fetchall()

    db.close()

    solved = {
        row["challenge_id"]
        for row in solved_rows
    }

    sections = {
        1: [],
        2: [],
        3: []
    }

    for challenge in CHALLENGES:

        sections[
            challenge["section"]
        ].append(challenge)

    score = 0

    for challenge in CHALLENGES:

        if challenge["id"] in solved:

            score += challenge["points"]

    return render_template(
        "dashboard.html",

        user=user,

        sections=sections,

        solved=solved,

        score=score,
        participant_elapsed=participant_elapsed_seconds(user),
        easy_unlocked=True,
        moderate_unlocked=True,
        hard_unlocked=True,
        easy_unlock_seconds=0,
        moderate_unlock_seconds=0,
        hard_unlock_seconds=0
    )


# --------------------------------------------------
# CHALLENGE
# --------------------------------------------------

@app.route("/challenge/<int:challenge_id>", methods=["GET", "POST"])
def challenge(challenge_id):
    user = current_user()
    if not user:
        return redirect(url_for("login"))
    challenge_data = next((c for c in CHALLENGES if c["id"] == challenge_id), None)
    if not challenge_data:
        return "Challenge not found", 404
    cfg = event_config()
    section = challenge_data["section"]
    # Round access is immediate for every active participant.
    unlocked = True
    if request.method == "POST":
        if not is_event_running():
            flash("Flag submissions are available only while the CTF is running.")
            return redirect(url_for("challenge", challenge_id=challenge_id))
        if not unlocked:
            flash("This round is still locked.")
            return redirect(url_for("dashboard"))
        flag = request.form.get("flag", "").strip()
        if not flag:
            flash("Enter a flag first.")
            return redirect(url_for("challenge", challenge_id=challenge_id))
        db = get_db()
        attempts = db.execute("SELECT COUNT(*) FROM flag_attempts WHERE user_id=? AND challenge_id=?", (user["id"], challenge_id)).fetchone()[0]
        solved_rows = db.execute("SELECT flag_index FROM flag_solves WHERE user_id=? AND challenge_id=?", (user["id"], challenge_id)).fetchall()
        solved_indices = {r["flag_index"] for r in solved_rows}
        if len(solved_indices) >= challenge_data["flag_count"]:
            db.close(); flash("All flags for this question have been solved.")
            return redirect(url_for("challenge", challenge_id=challenge_id))
        max_attempts = cfg["max_attempts"] if cfg else 5
        if attempts >= max_attempts:
            db.close(); flash(f"Attempt limit reached ({max_attempts} per question).")
            return redirect(url_for("challenge", challenge_id=challenge_id))
        now = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        try:
            flag_index = challenge_data["flags"].index(flag) + 1
        except ValueError:
            flag_index = 0
        correct = flag_index > 0 and flag_index not in solved_indices
        db.execute("INSERT INTO flag_attempts(user_id, challenge_id, correct, submitted_at) VALUES (?,?,?,?)", (user["id"], challenge_id, int(correct), now))
        total_milli = int(challenge_data["points"] * 1000)
        base_points, remainder = divmod(total_milli, challenge_data["flag_count"])
        points_milli = (base_points + (1 if flag_index <= remainder else 0)) if correct else 0
        if correct:
            db.execute("INSERT OR IGNORE INTO flag_solves(user_id, challenge_id, flag_index, points_milli, solved_at) VALUES (?,?,?,?,?)", (user["id"], challenge_id, flag_index, points_milli, now))
        db.commit()
        remaining = max(0, max_attempts - attempts - 1)
        db.close()
        if correct:
            flash(f"Correct flag {flag_index}/{challenge_data['flag_count']}! +{points_milli/1000:g} points. {remaining} attempts remaining.")
        elif flag_index in solved_indices:
            flash(f"You already submitted that flag. {remaining} attempts remaining.")
        else:
            flash(f"Incorrect flag. {remaining} attempts remaining.")
        return redirect(url_for("challenge", challenge_id=challenge_id))
    db = get_db()
    attempts = db.execute("SELECT COUNT(*) FROM flag_attempts WHERE user_id=? AND challenge_id=?", (user["id"], challenge_id)).fetchone()[0]
    solved_rows = db.execute("SELECT flag_index, points_milli, solved_at FROM flag_solves WHERE user_id=? AND challenge_id=? ORDER BY flag_index", (user["id"], challenge_id)).fetchall()
    db.close()
    max_attempts = cfg["max_attempts"] if cfg else 5
    solved_indices = {r["flag_index"] for r in solved_rows}
    solved = len(solved_indices) == challenge_data["flag_count"]
    remaining_attempts = max(0, max_attempts - attempts)
    return render_template("challenge.html", challenge=challenge_data, solved=solved, solved_indices=solved_indices, solved_rows=solved_rows, attempts_used=attempts, remaining_attempts=remaining_attempts, max_attempts=max_attempts, round_unlocked=unlocked)


# --------------------------------------------------
# SCOREBOARD
# --------------------------------------------------

@app.route("/scoreboard")
def scoreboard():
    db = get_db()
    rows = db.execute("""
      SELECT u.username, COALESCE(SUM(fs.points_milli),0)/1000.0 AS score,
             COUNT(fs.id) AS solved, MAX(fs.solved_at) AS final_solve_at
      FROM users u LEFT JOIN flag_solves fs ON fs.user_id=u.id
      WHERE u.is_admin=0 AND u.disqualified=0
      GROUP BY u.id ORDER BY score DESC, solved DESC, final_solve_at ASC, u.username ASC
    """).fetchall()
    db.close()
    return render_template("scoreboard.html", rows=rows)


@app.route("/api/scoreboard")
def scoreboard_api():
    db = get_db()
    rows = db.execute("""SELECT u.username, COALESCE(SUM(fs.points_milli),0)/1000.0 score,
        COUNT(fs.id) solved, MAX(fs.solved_at) final_solve_at FROM users u
        LEFT JOIN flag_solves fs ON fs.user_id=u.id WHERE u.is_admin=0 AND u.disqualified=0
        GROUP BY u.id ORDER BY score DESC, solved DESC, final_solve_at ASC, u.username ASC""").fetchall()
    state = db.execute("SELECT status FROM event WHERE id=1").fetchone()
    db.close()
    return jsonify({"status": state["status"], "updated_at": india_time(datetime.now(timezone.utc).isoformat()),
      "rows": [{"rank": i+1, "username": r["username"], "score": r["score"] or 0, "solved": r["solved"] or 0, "final_solve_at": india_time(r["final_solve_at"])} for i,r in enumerate(rows)]})


# --------------------------------------------------
# ADMIN
# --------------------------------------------------

@app.route("/admin")
def admin():

    user = current_user()

    if not user or not user["is_admin"]:

        return "Access denied", 403

    db = get_db()
    users = db.execute("SELECT id, username, is_admin, created_at, joined_at, last_login_at, login_count, disqualified, disqualified_reason, disqualified_at FROM users ORDER BY is_admin DESC, username ASC").fetchall()
    activity = db.execute("SELECT users.username, flag_attempts.challenge_id, flag_attempts.correct, flag_attempts.submitted_at FROM flag_attempts JOIN users ON users.id = flag_attempts.user_id ORDER BY flag_attempts.submitted_at DESC LIMIT 250").fetchall()
    stats = {
        "participants": db.execute("SELECT COUNT(*) FROM users WHERE is_admin = 0").fetchone()[0],
        "active": db.execute("SELECT COUNT(*) FROM users WHERE is_admin = 0 AND disqualified = 0").fetchone()[0],
        "disqualified": db.execute("SELECT COUNT(*) FROM users WHERE is_admin = 0 AND disqualified = 1").fetchone()[0],
        "attempts": db.execute("SELECT COUNT(*) FROM flag_attempts").fetchone()[0],
        "correct": db.execute("SELECT COUNT(*) FROM flag_attempts WHERE correct = 1").fetchone()[0],
        "logins": db.execute("SELECT COUNT(*) FROM login_events").fetchone()[0],
    }
    event_row = db.execute("SELECT * FROM event WHERE id = 1").fetchone()
    alerts = db.execute("SELECT * FROM security_alerts ORDER BY created_at DESC LIMIT 50").fetchall()
    reviews = db.execute("SELECT r.*, u.username FROM disqualification_reviews r JOIN users u ON u.id=r.user_id ORDER BY r.submitted_at DESC LIMIT 50").fetchall()
    db.close()
    return render_template("admin.html", users=users, activity=activity, stats=stats, event_row=event_row, alerts=alerts, reviews=reviews)




@app.route("/admin/users/create", methods=["POST"])
def admin_create_user():
    user = current_user()
    if not user or not user["is_admin"]:
        return "Access denied", 403
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    if len(username) < 3 or not password:
        flash("Username must be at least 3 characters and password must not be empty.")
    elif create_user(username, password, is_admin=False):
        db = get_db()
        target = db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone()
        db.execute("INSERT INTO audit_log(actor_user_id, action, target_user_id, details, created_at) VALUES (?, 'create_participant', ?, ?, ?)", (user["id"], target["id"] if target else None, f"Created account: {username}", datetime.now(timezone.utc).isoformat()))
        db.commit(); db.close()
        flash(f"Participant account created for {username}.")
    else:
        flash("Could not create account. The username may already exist.")
    return redirect(url_for("admin"))


@app.route("/admin/users/<int:user_id>/disqualify", methods=["POST"])
def admin_disqualify_user(user_id):
    admin_user = current_user()
    if not admin_user or not admin_user["is_admin"]:
        return "Access denied", 403
    reason = request.form.get("reason", "").strip()[:250]
    db = get_db()
    target = db.execute("SELECT id, is_admin FROM users WHERE id = ?", (user_id,)).fetchone()
    if not target:
        flash("User not found.")
    elif target["is_admin"]:
        flash("Administrator accounts cannot be disqualified from this panel.")
    elif user_id == admin_user["id"]:
        flash("You cannot disqualify your own administrator account.")
    else:
        now = datetime.now(timezone.utc).isoformat()
        db.execute("UPDATE users SET disqualified = 1, disqualified_reason = ?, disqualified_at = ? WHERE id = ?", (reason or "Disqualified by administrator", now, user_id))
        db.execute("INSERT INTO audit_log(actor_user_id, action, target_user_id, details, created_at) VALUES (?, 'disqualify_participant', ?, ?, ?)", (admin_user["id"], user_id, reason or "Disqualified by administrator", now))
        db.commit()
        flash("Participant disqualified; they can no longer log in and are removed from the scoreboard.")
    db.close()
    return redirect(url_for("admin"))

@app.route("/admin/users/<int:user_id>/reactivate", methods=["POST"])
def admin_reactivate_user(user_id):
    admin_user = current_user()
    if not admin_user or not admin_user["is_admin"]:
        return "Access denied", 403
    db = get_db()
    target = db.execute("SELECT id, is_admin, disqualified FROM users WHERE id = ?", (user_id,)).fetchone()
    if not target:
        flash("Participant not found.")
    elif target["is_admin"]:
        flash("This action is only for participant accounts.")
    elif not target["disqualified"]:
        flash("This participant is already active.")
    else:
        now = datetime.now(timezone.utc).isoformat(timespec="microseconds")
        db.execute("UPDATE users SET disqualified=0, disqualified_reason=NULL, disqualified_at=NULL WHERE id=?", (user_id,))
        db.execute("INSERT INTO audit_log(actor_user_id, action, target_user_id, details, created_at) VALUES (?, 'participant_reactivated', ?, ?, ?)", (admin_user["id"], user_id, "Participant reactivated by administrator", now))
        db.commit()
        flash("Participant reactivated. They can log in again.")
    db.close()
    return redirect(url_for("admin"))

@app.route("/admin/start", methods=["POST"])
def admin_start():
    admin_user = current_user()
    if not admin_user or not admin_user["is_admin"]:
        return "Access denied", 403
    now = datetime.now(timezone.utc).isoformat()
    db = get_db()
    event = db.execute("SELECT status FROM event WHERE id=1").fetchone()
    if event and event["status"] == "running":
        flash("The CTF is already running. Pause or end it before restarting.")
    else:
        # Starting after a previous run is an explicit fresh run: clear current scoring
        # and participant clocks while preserving attempts and audit history.
        db.execute("DELETE FROM submissions")
        db.execute("UPDATE users SET joined_at=NULL WHERE is_admin=0")
        db.execute("UPDATE event SET started_at=?, ended_at=NULL, paused_at=NULL, status='running', easy_override=0, moderate_override=0, hard_override=0 WHERE id=1", (now,))
        db.execute("INSERT INTO audit_log(actor_user_id, action, details, created_at) VALUES (?, 'event_start_or_restart', ?, ?)", (admin_user["id"], "CTF started/restarted; current scores and participant clocks reset", now))
        db.commit()
        flash("CTF started/restarted. Current scores and participant clocks were reset; historical attempts remain in the audit records.")
    db.close()
    return redirect(url_for("admin"))


@app.route("/admin/event/control", methods=["POST"])
def admin_event_control():
    user = current_user()
    if not user or not user["is_admin"]: return "Access denied", 403
    action = request.form.get("action", "")
    now = datetime.now(timezone.utc).isoformat()
    db = get_db()
    event = db.execute("SELECT * FROM event WHERE id=1").fetchone()
    if action == "pause" and event["status"] == "running":
        db.execute("UPDATE event SET status='paused', paused_at=? WHERE id=1", (now,))
    elif action == "resume" and event["status"] == "paused":
        # Shift start time by paused duration so the global duration timer does not run while paused.
        try:
            start = datetime.fromisoformat(event["started_at"])
            paused = datetime.fromisoformat(event["paused_at"])
            shifted = start + (datetime.fromisoformat(now) - paused)
            db.execute("UPDATE event SET status='running', started_at=?, paused_at=NULL WHERE id=1", (shifted.isoformat(),))
        except (TypeError, ValueError):
            db.execute("UPDATE event SET status='running', paused_at=NULL WHERE id=1")
    elif action == "end" and event["status"] in ("running", "paused"):
        db.execute("UPDATE event SET status='ended', ended_at=? WHERE id=1", (now,))
    elif action == "configure":
        try:
            duration = int(request.form["duration_seconds"])
            max_attempts = int(request.form.get("max_attempts", "5"))
            if duration < 60 or duration > 604800 or not 1 <= max_attempts <= 20:
                raise ValueError
            # Persist zero round delays as well, so older settings cannot re-lock rounds.
            db.execute("UPDATE event SET easy_seconds=0, moderate_seconds=0, hard_seconds=0, duration_seconds=?, max_attempts=? WHERE id=1", (duration, max_attempts))
        except (ValueError, TypeError, KeyError):
            flash("Invalid settings. Event duration must be 60–604800 seconds and attempts must be 1–20.")
            db.close(); return redirect(url_for("admin"))
    else:
        flash("That event control action is not valid for the current state.")
        db.close(); return redirect(url_for("admin"))
    db.execute("INSERT INTO audit_log(actor_user_id, action, details, created_at) VALUES (?, ?, ?, ?)", (user["id"], "event_"+action, f"Event control: {action}", now))
    db.commit(); db.close()
    flash("Event control updated: " + action)
    return redirect(url_for("admin"))


@app.route("/disqualification-review", methods=["POST"])
def disqualification_review():
    # Re-authenticate the locked-out participant for review submission only.
    username=request.form.get("username", "").strip()
    password=request.form.get("password", "")
    reason=request.form.get("reason", "").strip()[:1000]
    user=authenticate(username, password)
    if not user or not user["disqualified"] or len(reason) < 10:
        flash("Review request not accepted. Verify the disqualified account credentials and provide a reason of at least 10 characters.")
        return redirect(url_for("login"))
    db=get_db(); now=datetime.now(timezone.utc).isoformat()
    db.execute("INSERT INTO disqualification_reviews(user_id, reason, submitted_at) VALUES (?, ?, ?)", (user["id"],reason,now))
    db.execute("INSERT INTO audit_log(actor_user_id, action, target_user_id, details, created_at) VALUES (?, 'disqualification_review_submitted', ?, ?, ?)", (user["id"],user["id"],reason,now))
    db.commit(); db.close(); flash("Review request submitted for administrator review.")
    return redirect(url_for("login"))


@app.route("/admin/reviews/<int:review_id>", methods=["POST"])
def admin_review_decision(review_id):
    user=current_user()
    if not user or not user["is_admin"]: return "Access denied", 403
    decision=request.form.get("decision", "")
    notes=request.form.get("notes", "").strip()[:1000]
    if decision not in ("approve", "reject"): return "Invalid decision", 400
    db=get_db(); now=datetime.now(timezone.utc).isoformat()
    review=db.execute("SELECT * FROM disqualification_reviews WHERE id=? AND status='pending'", (review_id,)).fetchone()
    if not review:
        db.close(); flash("Review not found or already processed."); return redirect(url_for("admin"))
    status="approved" if decision=="approve" else "rejected"
    db.execute("UPDATE disqualification_reviews SET status=?, reviewed_at=?, reviewer_id=?, reviewer_notes=? WHERE id=?", (status,now,user["id"],notes,review_id))
    if decision=="approve": db.execute("UPDATE users SET disqualified=0, disqualified_reason=NULL, disqualified_at=NULL WHERE id=?", (review["user_id"],))
    db.execute("INSERT INTO audit_log(actor_user_id, action, target_user_id, details, created_at) VALUES (?, ?, ?, ?, ?)", (user["id"],"disqualification_review_"+status,review["user_id"],notes or status,now))
    db.commit(); db.close(); flash("Review " + status + "."); return redirect(url_for("admin"))



@app.route("/admin/backup", methods=["POST"])
def admin_backup():
    user=current_user()
    if not user or not user["is_admin"]: return "Access denied", 403
    from config import DATABASE
    source=Path(DATABASE); backup_dir=Path("backups"); backup_dir.mkdir(parents=True, exist_ok=True)
    target=backup_dir / ("ctf-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + ".db")
    src=get_db(); dst=__import__("sqlite3").connect(str(target))
    try: src.backup(dst); dst.close(); size=target.stat().st_size; status="success"
    except Exception:
        dst.close(); size=0; status="failed"; raise
    finally: src.close()
    db=get_db(); now=datetime.now(timezone.utc).isoformat()
    db.execute("INSERT INTO backup_log(path, created_at, bytes, status) VALUES (?, ?, ?, ?)", (str(target),now,size,status))
    db.execute("INSERT INTO audit_log(actor_user_id, action, details, created_at) VALUES (?, 'database_backup', ?, ?)", (user["id"],str(target),now))
    db.commit(); db.close(); flash(f"Database backup created: {target}"); return redirect(url_for("admin"))


@app.route(
    "/admin/reset",
    methods=["POST"]
)
def admin_reset():

    user = current_user()

    if not user or not user["is_admin"]:

        return "Access denied", 403

    db = get_db()

    db.execute("DELETE FROM submissions")
    db.execute("UPDATE users SET joined_at = NULL WHERE is_admin = 0")

    db.execute(
        """
        UPDATE event

        SET started_at = NULL, ended_at = NULL, status = 'not_started'

        WHERE id = 1
        """
    )

    db.execute("INSERT INTO audit_log(actor_user_id, action, details, created_at) VALUES (?, 'event_reset', 'Scoreboard and round timers reset; historical audit records retained', ?)", (user["id"], datetime.now(timezone.utc).isoformat()))
    db.commit()
    db.close()

    flash("CTF reset. Scores and participant timers were reset; historical audit records were retained.")

    return redirect(
        url_for("admin")
    )


@app.route("/admin/export-participants.xlsx")
def admin_export_participants_excel():
    admin_user = current_user()
    if not admin_user or not admin_user["is_admin"]:
        return "Access denied", 403
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except ImportError:
        flash("Excel export dependency missing. Run: pip install openpyxl")
        return redirect(url_for("admin"))
    db = get_db()
    participant_rows = db.execute("SELECT id, username, is_admin, created_at, joined_at, last_login_at, login_count, disqualified, disqualified_reason, disqualified_at FROM users ORDER BY is_admin DESC, username ASC").fetchall()
    score_rows = db.execute("SELECT u.username, COUNT(CASE WHEN s.correct=1 THEN 1 END) AS solved, COALESCE(SUM(CASE WHEN s.correct=1 THEN c.points ELSE 0 END),0) AS points, MAX(CASE WHEN s.correct=1 THEN s.first_correct_at END) AS last_correct_solve FROM users u LEFT JOIN submissions s ON s.user_id=u.id LEFT JOIN (SELECT id, points FROM challenges) c ON c.id=s.challenge_id GROUP BY u.id ORDER BY u.username").fetchall() if False else []
    attempts = db.execute("SELECT u.username, fa.challenge_id, fa.correct, fa.submitted_at FROM flag_attempts fa JOIN users u ON u.id=fa.user_id ORDER BY fa.submitted_at").fetchall()
    db.close()
    wb = Workbook()
    ws = wb.active
    ws.title = "Data of Participants"
    headers = ["User ID", "Username", "Role", "Account Created (IST)", "First Login (IST)", "Last Login (IST)", "Login Count", "Disqualified", "Disqualification Reason", "Disqualified At (IST)"]
    ws.append(headers)
    for row in participant_rows:
        ws.append([row["id"], row["username"], "Admin" if row["is_admin"] else "Participant", india_time(row["created_at"]), india_time(row["joined_at"]), india_time(row["last_login_at"]), row["login_count"], "Yes" if row["disqualified"] else "No", row["disqualified_reason"], india_time(row["disqualified_at"])])
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="243B64")
        cell.alignment = Alignment(wrap_text=True)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for col in ws.columns:
        width = min(max(max(len(str(c.value or "")) for c in col) + 2, 14), 42)
        ws.column_dimensions[get_column_letter(col[0].column)].width = width
    wa = wb.create_sheet("Flag Attempts")
    wa.append(["Username", "Challenge ID", "Result", "Submitted At (IST)"])
    for row in attempts:
        wa.append([row["username"], row["challenge_id"], "Correct" if row["correct"] else "Incorrect", india_time(row["submitted_at"])])
    for cell in wa[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="243B64")
    wa.freeze_panes = "A2"
    wa.auto_filter.ref = wa.dimensions
    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return send_file(output, as_attachment=True, download_name="data of participents.xlsx", mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/admin/export.zip")
def admin_export():
    user = current_user()
    if not user or not user["is_admin"]:
        return "Access denied", 403
    db = get_db()
    exports = {
        "participants.csv": db.execute("SELECT id, username, is_admin, created_at, joined_at, last_login_at, login_count, disqualified, disqualified_reason, disqualified_at FROM users ORDER BY id").fetchall(),
        "flag_attempts.csv": db.execute("SELECT id, user_id, challenge_id, correct, submitted_at FROM flag_attempts ORDER BY id").fetchall(),
        "login_events.csv": db.execute("SELECT id, username_attempted, user_id, success, attempted_at FROM login_events ORDER BY id").fetchall(),
        "administrator_audit.csv": db.execute("SELECT id, actor_user_id, action, target_user_id, details, created_at FROM audit_log ORDER BY id").fetchall(),
        "event_state.csv": db.execute("SELECT id, started_at, ended_at, status FROM event ORDER BY id").fetchall(),
        "current_scores.csv": db.execute("SELECT u.username, s.challenge_id, s.correct, s.submitted_at, s.first_correct_at FROM submissions s JOIN users u ON u.id = s.user_id ORDER BY u.username, s.challenge_id").fetchall(),
        "solved_flags.csv": db.execute("SELECT u.username, fs.challenge_id, fs.flag_index, fs.points_milli, fs.solved_at FROM flag_solves fs JOIN users u ON u.id=fs.user_id ORDER BY fs.solved_at").fetchall(),
        "round_overrides.csv": db.execute("SELECT ro.id, u.username AS administrator, ro.round_section, ro.override_at FROM round_overrides ro JOIN users u ON u.id=ro.actor_user_id ORDER BY ro.id").fetchall(),
        "security_alerts.csv": db.execute("SELECT id, alert_type, severity, details, created_at, reviewed_at, reviewed_by FROM security_alerts ORDER BY id").fetchall(),
        "disqualification_reviews.csv": db.execute("SELECT id, user_id, reason, status, submitted_at, reviewed_at, reviewer_id, reviewer_notes FROM disqualification_reviews ORDER BY id").fetchall(),
        "backup_log.csv": db.execute("SELECT id, path, created_at, bytes, status FROM backup_log ORDER BY id").fetchall(),
    }
    db.close()
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for filename, rows in exports.items():
            csv_buffer = io.StringIO()
            writer = csv.writer(csv_buffer)
            if rows:
                writer.writerow(rows[0].keys())
                for row in rows:
                    writer.writerow([india_time(row[key]) if key.endswith(("_at", "_time")) and row[key] else row[key] for key in row.keys()])
            else:
                writer.writerow(["No records"])
            archive.writestr(filename, csv_buffer.getvalue())
    from flask import Response
    return Response(output.getvalue(), mimetype="application/zip", headers={"Content-Disposition": "attachment; filename=ctf_full_audit_export.zip"})


# --------------------------------------------------
# RUN
# --------------------------------------------------

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False
    )

