"""Create a consistent SQLite backup using SQLite's online backup API."""
from pathlib import Path
from datetime import datetime, timezone
import sqlite3
from config import DATABASE

def main():
    source_path=Path(DATABASE)
    if not source_path.exists():
        raise SystemExit(f"Database not found: {source_path}. Start the app once first.")
    backup_dir=Path('backups'); backup_dir.mkdir(parents=True,exist_ok=True)
    target=backup_dir / ('ctf-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.db')
    with sqlite3.connect(str(source_path)) as src, sqlite3.connect(str(target)) as dst:
        src.backup(dst)
    print(f'Backup created: {target} ({target.stat().st_size} bytes)')
if __name__=='__main__': main()
