# IEEE × GEHU CTF Platform — Version 4

Flask-based CTF competition website retaining the existing IEEE/GEHU visual assets.

## Version 4 features
- Each question supports multiple independently validated flags: 3 for Easy and 5 for Moderate/Hard. The original flag remains flag 1; additional stage flags are listed in `challenges.py` and should be incorporated into the challenge content before launch.
- Partial points are awarded per distinct flag; points are stored as thousandths to reduce rounding drift.
- Admin-configurable attempts per question (default 5), remaining-attempt display, and lockout after the limit.
- All three rounds open immediately; no per-round waiting timers or override code are used.
- Flag submissions and solved-flag timestamps are stored in UTC and displayed in Indian Standard Time (24-hour format).

## Version 3 features
- Admin live event control: start, pause, resume, end, configure total event duration and maximum attempts per question in the dashboard. The server checks event state before accepting flag submissions.
- Live scoreboard refreshes every five seconds and displays rank, score, solved count and final counted solve timestamp.
- Persistent SQLite database with automatic schema migrations, WAL mode, busy timeout and records for participants, submissions, all flag attempts, logins, security alerts, disqualification reviews, event settings, audit actions and backups.
- Login throttling: five failed attempts in a rolling 10-minute window for an IP address triggers a 10-minute block and a security alert. The app uses the direct peer address; configure trusted proxies carefully if deployed behind a reverse proxy.
- Append-only audit table enforced by SQLite triggers. This helps prevent ordinary application-level edits, but is not cryptographically immutable against someone who can alter the database file. Copy audit exports/backups to separate access-controlled storage for stronger evidence retention.
- Disqualification review workflow: disqualified participants can re-authenticate from the login page and submit a reason; an administrator can approve or reject it with notes.
- Admin can create an online SQLite-consistent backup and export CSV audit reports. `backup_database.py` creates timestamped backups using SQLite's online backup API.
- `performance_test.py` checks HTTP scoreboard response times/errors for 25/50/100/200 simulated concurrent workers. `database_write_benchmark.py` measures write contention on a disposable test DB. Optional `psutil` reports host CPU snapshots.

## Install and run locally on Windows
Open PowerShell in the folder containing `app.py`:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
python create_admin.py
python app.py
```

Open http://127.0.0.1:5000. `create_admin.py` asks you to choose credentials. Do not use the Flask development server for a public event.

## Production server
Set a long random secret in your deployment environment. For example, generate one locally with:

```powershell
python -c "import secrets; print(secrets.token_hex(32))"
$env:CTF_SECRET_KEY = "paste-the-generated-value-here"
$env:CTF_HTTPS = "1"
waitress-serve --listen=127.0.0.1:8080 app:app
```

Put a properly configured HTTPS reverse proxy/load balancer in front of Waitress, restrict the origin port to localhost/private network, use a valid certificate, and ensure the proxy strips untrusted forwarded headers. Set `CTF_HTTPS=1` only when browsers reach the app through HTTPS; it enables Secure session cookies. Never expose the development server directly to the internet.

## Round timing
All three rounds are available immediately after the event is running. The administrator can configure the total event duration and maximum attempts per question. Pausing the event pauses submissions and the global event timer.

## Database and backups
- Default DB: `data/ctf.db`; use `CTF_DATABASE_PATH` to override it.
- Manual backup from Admin creates a timestamped file under `backups/`.
- Scheduled backup: use Windows Task Scheduler to run `python backup_database.py` daily and before/after the event. Set the task's **Start in** directory to this project folder and run it as a restricted service account. Keep copies in a separate, access-controlled location; periodically restore a copy to a test folder and verify the site can read it. Never store the only backup on the same laptop.
- Do not include the `backups/` folder or participant exports in a public web root or Git repository.
- CSV exports are sensitive competition records; limit downloads to administrators and handle them under event privacy rules.

## Load testing
Run the site in one terminal. In a second terminal:

```powershell
python performance_test.py --url http://127.0.0.1:5000 --levels 25 50 100 200 --requests-per-user 10
python database_write_benchmark.py --levels 25 50 100 200 --writes-per-user 10
```

These scripts generate test traffic/write load. Run only against systems you own or are authorized to test. The HTTP script exercises the scoreboard endpoint, not authenticated challenge submission; the SQLite script tests disposable DB contention, not the live app's full workload. Record latency, errors, CPU, database locks and server logs, then separately test a realistic burst of logged-in flag submissions before announcing capacity. Do not infer a guaranteed user count from the test levels alone.

## Important limitations and launch checklist
1. Test pause/resume/end, timer configuration, participant reactivation, disqualification review, scoreboard tie-breaking, backups and restoration with test accounts.
2. Audit triggers are append-only at the SQLite application layer but are not tamper-proof against a person with direct file/database control. For stronger evidence, export signed/hash-chained logs to remote append-only storage.
3. Login throttling by source IP can affect multiple users behind the same NAT; tune policy and monitor false positives before an event.
4. The built-in test scripts are a baseline, not a full security/load audit. Run against the actual hardware/network and expected traffic pattern.
5. For sustained 100+ concurrent participants or heavy simultaneous writes, evaluate PostgreSQL, a production host, HTTPS, monitoring and backups tested through restoration.
