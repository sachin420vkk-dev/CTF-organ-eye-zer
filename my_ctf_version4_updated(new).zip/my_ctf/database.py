"""SQLite persistence and schema migrations for the CTF platform."""
import os
import sqlite3
from config import DATABASE


def get_db():
    os.makedirs(os.path.dirname(DATABASE) or ".", exist_ok=True)
    connection = sqlite3.connect(DATABASE, timeout=20)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 20000")
    return connection


def _add_column_if_missing(db, table, column, declaration):
    columns = {row[1] for row in db.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in columns:
        db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {declaration}")


def init_db():
    db = get_db()
    # WAL improves reader/writer coexistence for a small live event.
    db.execute("PRAGMA journal_mode = WAL")
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        is_admin INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        joined_at TEXT,
        last_login_at TEXT,
        login_count INTEGER NOT NULL DEFAULT 0,
        disqualified INTEGER NOT NULL DEFAULT 0,
        disqualified_reason TEXT,
        disqualified_at TEXT
    );
    CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        challenge_id INTEGER NOT NULL,
        correct INTEGER NOT NULL DEFAULT 0,
        submitted_at TEXT NOT NULL,
        first_correct_at TEXT,
        UNIQUE(user_id, challenge_id),
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS flag_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        challenge_id INTEGER NOT NULL,
        correct INTEGER NOT NULL,
        submitted_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS flag_solves (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
        challenge_id INTEGER NOT NULL, flag_index INTEGER NOT NULL,
        points_milli INTEGER NOT NULL, solved_at TEXT NOT NULL,
        UNIQUE(user_id, challenge_id, flag_index),
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS round_overrides (
        id INTEGER PRIMARY KEY AUTOINCREMENT, actor_user_id INTEGER NOT NULL,
        round_section INTEGER NOT NULL, override_at TEXT NOT NULL,
        FOREIGN KEY(actor_user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS login_events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username_attempted TEXT NOT NULL,
        user_id INTEGER,
        success INTEGER NOT NULL,
        attempted_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        actor_user_id INTEGER,
        action TEXT NOT NULL,
        target_user_id INTEGER,
        details TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(actor_user_id) REFERENCES users(id),
        FOREIGN KEY(target_user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS event (
        id INTEGER PRIMARY KEY CHECK(id = 1),
        started_at TEXT,
        ended_at TEXT,
        status TEXT NOT NULL DEFAULT 'not_started',
        paused_at TEXT,
        easy_seconds INTEGER NOT NULL DEFAULT 300,
        moderate_seconds INTEGER NOT NULL DEFAULT 1200,
        hard_seconds INTEGER NOT NULL DEFAULT 1200,
        duration_seconds INTEGER NOT NULL DEFAULT 21600,
        max_attempts INTEGER NOT NULL DEFAULT 5,
        easy_override INTEGER NOT NULL DEFAULT 0,
        moderate_override INTEGER NOT NULL DEFAULT 0,
        hard_override INTEGER NOT NULL DEFAULT 0
    );
    INSERT OR IGNORE INTO event(id, started_at, ended_at, status) VALUES(1, NULL, NULL, 'not_started');
    CREATE INDEX IF NOT EXISTS idx_flag_attempts_user_time ON flag_attempts(user_id, submitted_at);
    CREATE INDEX IF NOT EXISTS idx_flag_attempts_challenge ON flag_attempts(challenge_id, correct);
    CREATE INDEX IF NOT EXISTS idx_login_events_time ON login_events(attempted_at);
    CREATE INDEX IF NOT EXISTS idx_audit_log_time ON audit_log(created_at);
    CREATE TRIGGER IF NOT EXISTS audit_log_no_update BEFORE UPDATE ON audit_log BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
    CREATE TRIGGER IF NOT EXISTS audit_log_no_delete BEFORE DELETE ON audit_log BEGIN SELECT RAISE(ABORT, 'audit_log is append-only'); END;
    CREATE TABLE IF NOT EXISTS login_rate_limits (
        ip_key TEXT PRIMARY KEY, window_started_at TEXT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0, blocked_until TEXT
    );
    CREATE TABLE IF NOT EXISTS security_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, alert_type TEXT NOT NULL,
        severity TEXT NOT NULL DEFAULT 'medium', details TEXT NOT NULL,
        created_at TEXT NOT NULL, reviewed_at TEXT, reviewed_by INTEGER,
        FOREIGN KEY(reviewed_by) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS disqualification_reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
        reason TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
        submitted_at TEXT NOT NULL, reviewed_at TEXT, reviewer_id INTEGER,
        reviewer_notes TEXT, FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(reviewer_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS backup_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT NOT NULL,
        created_at TEXT NOT NULL, bytes INTEGER NOT NULL, status TEXT NOT NULL
    );
    """)
    # Migrate older databases without deleting existing records.
    _add_column_if_missing(db, "users", "joined_at", "TEXT")
    _add_column_if_missing(db, "users", "last_login_at", "TEXT")
    _add_column_if_missing(db, "users", "login_count", "INTEGER NOT NULL DEFAULT 0")
    _add_column_if_missing(db, "users", "disqualified", "INTEGER NOT NULL DEFAULT 0")
    _add_column_if_missing(db, "users", "disqualified_reason", "TEXT")
    _add_column_if_missing(db, "users", "disqualified_at", "TEXT")
    _add_column_if_missing(db, "submissions", "first_correct_at", "TEXT")
    _add_column_if_missing(db, "event", "ended_at", "TEXT")
    _add_column_if_missing(db, "event", "status", "TEXT NOT NULL DEFAULT 'not_started'")
    _add_column_if_missing(db, "event", "paused_at", "TEXT")
    _add_column_if_missing(db, "event", "easy_seconds", "INTEGER NOT NULL DEFAULT 300")
    _add_column_if_missing(db, "event", "moderate_seconds", "INTEGER NOT NULL DEFAULT 1200")
    _add_column_if_missing(db, "event", "hard_seconds", "INTEGER NOT NULL DEFAULT 1200")
    _add_column_if_missing(db, "event", "duration_seconds", "INTEGER NOT NULL DEFAULT 21600")
    _add_column_if_missing(db, "event", "max_attempts", "INTEGER NOT NULL DEFAULT 5")
    _add_column_if_missing(db, "event", "easy_override", "INTEGER NOT NULL DEFAULT 0")
    _add_column_if_missing(db, "event", "moderate_override", "INTEGER NOT NULL DEFAULT 0")
    _add_column_if_missing(db, "event", "hard_override", "INTEGER NOT NULL DEFAULT 0")
    db.commit()
    db.close()
