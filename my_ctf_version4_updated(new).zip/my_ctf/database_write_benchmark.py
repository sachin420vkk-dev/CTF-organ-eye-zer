"""Measure SQLite write contention on a disposable test database, not production data."""
import argparse, concurrent.futures, sqlite3, tempfile, time, os, statistics
from pathlib import Path
try: import psutil
except ImportError: psutil=None

def main():
    p=argparse.ArgumentParser(); p.add_argument('--levels',nargs='+',type=int,default=[25,50,100,200]); p.add_argument('--writes-per-user',type=int,default=10); a=p.parse_args()
    print('concurrency,writes,errors,p50_write_ms,p95_write_ms,max_write_ms,cpu_before,cpu_after')
    for workers in a.levels:
        if workers<1: continue
        with tempfile.TemporaryDirectory() as td:
            dbpath=str(Path(td)/'bench.db')
            with sqlite3.connect(dbpath) as db:
                db.execute('PRAGMA journal_mode=WAL'); db.execute('CREATE TABLE bench(id INTEGER PRIMARY KEY, worker INTEGER, created REAL)')
            def writer(worker):
                vals=[]; errors=0
                for i in range(a.writes_per_user):
                    start=time.perf_counter()
                    try:
                        with sqlite3.connect(dbpath, timeout=5) as db:
                            db.execute('PRAGMA busy_timeout=5000'); db.execute('INSERT INTO bench(worker,created) VALUES (?,?)',(worker,time.time()))
                    except Exception: errors+=1
                    vals.append((time.perf_counter()-start)*1000)
                return vals,errors
            cb=psutil.cpu_percent(interval=.2) if psutil else 'n/a'
            with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool: results=list(pool.map(writer,range(workers)))
            ca=psutil.cpu_percent(interval=.2) if psutil else 'n/a'
            vals=[v for group,_ in results for v in group]; errs=sum(e for _,e in results); vals.sort()
            pct=lambda x: round(vals[min(len(vals)-1,int((len(vals)-1)*x))],2) if vals else 0
            print(f'{workers},{len(vals)},{errs},{pct(.5)},{pct(.95)},{round(max(vals,default=0),2)},{cb},{ca}')
    print('This measures disposable SQLite write contention only. It is not a substitute for end-to-end app load testing.')
if __name__=='__main__': main()
