CHALLENGES = [
    {
        "id": 1,
        "section": 1,
        "difficulty": "Easy",
        "title": "Welcome to the CTF",
        "description": """
Find the hidden flag in this introductory challenge.

Flag format:
CTF{...}
""",
        "answer": "CTF{welcome}",
        "points": 100,
        "hint": "Read everything carefully."
    },

    {
        "id": 2,
        "section": 1,
        "difficulty": "Easy",
        "title": "Encoded Secret",
        "description": """
Decode this message:

Q1RGe2Jhc2U2NF9pc19mdW58
""",
        "answer": "CTF{base64_is_fun}",
        "points": 100,
        "hint": "Look at the challenge title."
    },

    {
        "id": 3,
        "section": 1,
        "difficulty": "Easy",
        "title": "File Detective",
        "description": """
Analyze the supplied challenge file.

Find the hidden flag.
""",
        "answer": "CTF{file_detective}",
        "points": 100,
        "hint": "Try strings and metadata."
    },

    {
        "id": 4,
        "section": 2,
        "difficulty": "Moderate",
        "title": "Web Recon",
        "description": """
Investigate the local CTF website.

There is a hidden location containing a clue.
""",
        "answer": "CTF{hidden_web_path}",
        "points": 200,
        "hint": "Web crawlers are sometimes given special instructions."
    },

    {
        "id": 5,
        "section": 2,
        "difficulty": "Moderate",
        "title": "Source Hunter",
        "description": """
Inspect the source code of the challenge page.

Find the information the developer accidentally left behind.
""",
        "answer": "CTF{source_code_hunter}",
        "points": 200,
        "hint": "The rendered page isn't everything."
    },

    {
        "id": 6,
        "section": 2,
        "difficulty": "Moderate",
        "title": "Cookie Trouble",
        "description": """
Investigate the demonstration application's cookies.

Find the correct role and retrieve the flag.
""",
        "answer": "CTF{cookie_role}",
        "points": 200,
        "hint": "Inspect what the server sends to your browser."
    },

    {
        "id": 7,
        "section": 2,
        "difficulty": "Moderate",
        "title": "Crypto Chain",
        "description": """
A message has been encoded multiple times.

Recover the original flag.
""",
        "answer": "CTF{crypto_chain}",
        "points": 200,
        "hint": "Try common encodings one at a time."
    },

    {
        "id": 8,
        "section": 2,
        "difficulty": "Moderate",
        "title": "PCAP Investigation",
        "description": """
Analyze the supplied PCAP from the isolated CTF environment.

Find the suspicious communication and recover the flag.
""",
        "answer": "CTF{pcap_detective}",
        "points": 200,
        "hint": "Follow interesting HTTP traffic."
    },

    {
        "id": 9,
        "section": 3,
        "difficulty": "Hard",
        "title": "Broken Authentication",
        "description": """
An intentionally vulnerable local application contains
an authentication weakness.

Investigate the application and obtain the flag.

This challenge is designed only for the CTF lab.
""",
        "answer": "CTF{broken_authentication}",
        "points": 400,
        "hint": "Determine exactly what the application trusts."
    },

    {
        "id": 10,
        "section": 3,
        "difficulty": "Hard",
        "title": "Multi-Stage Web",
        "description": """
This challenge contains several connected stages.

Find the first clue, follow it to the next location,
and continue until you reach the final flag.
""",
        "answer": "CTF{multi_stage_web}",
        "points": 400,
        "hint": "The first discovery is not the final answer."
    },

    {
        "id": 11,
        "section": 3,
        "difficulty": "Hard",
        "title": "Forensics Deep Dive",
        "description": """
Investigate the supplied forensic evidence.

Two different artifacts contain related information.
Correlate them to recover the flag.
""",
        "answer": "CTF{forensics_deep_dive}",
        "points": 400,
        "hint": "One artifact tells you what to search for in the other."
    },

    {
        "id": 12,
        "section": 3,
        "difficulty": "Hard",
        "title": "Reverse Engineer",
        "description": """
Analyze the deliberately created CTF binary.

Determine the expected input and recover the flag.

Only analyze the supplied CTF binary.
""",
        "answer": "CTF{reverse_engineering}",
        "points": 400,
        "hint": "Begin with static analysis."
    },

    {
        "id": 13,
        "section": 3,
        "difficulty": "Hard",
        "title": "FINAL BOSS",
        "description": """
This is the final challenge.

Several clues are connected.

You will need to:

1. Investigate the initial information.
2. Discover the first artifact.
3. Analyze it.
4. Transform the information you find.
5. Use the result to locate the final flag.

Good luck.
""",
        "answer": "CTF{final_boss}",
        "points": 400,
        "hint": "The clues are connected. Don't analyze each artifact independently."
    }
]



# Version 4: independently validated flags per challenge. The original answer is
# retained as flag 1; additional flags are deterministic lab flags for the remaining stages.
for _challenge in CHALLENGES:
    _count = 3 if _challenge["difficulty"].lower() == "easy" else 5
    _base = _challenge["answer"].removeprefix("CTF{").removesuffix("}")
    _challenge["flags"] = [_challenge["answer"]] + [f"CTF{{{_base}_stage_{i}}}" for i in range(2, _count + 1)]
    _challenge["flag_count"] = _count
