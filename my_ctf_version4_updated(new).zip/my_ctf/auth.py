"""Authentication helpers. Passwords are stored using Werkzeug's salted PBKDF2 hash."""
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db


def create_user(username, password, is_admin=False):
    username = (username or "").strip()
    if len(username) < 3 or len(username) > 64 or not (password or ""):
        return False
    db = get_db()
    try:
        db.execute(
            "INSERT INTO users (username, password, is_admin, created_at) VALUES (?, ?, ?, datetime('now'))",
            (username, generate_password_hash(password), int(is_admin)),
        )
        db.commit()
        return True
    except Exception:
        db.rollback()
        return False
    finally:
        db.close()


def authenticate(username, password):
    db = get_db()
    try:
        user = db.execute("SELECT * FROM users WHERE username = ?", ((username or "").strip(),)).fetchone()
        if not user:
            return None
        stored = user["password"]
        # Backward-compatible migration: verify old SHA-256 hashes once, then upgrade.
        import hashlib
        legacy = hashlib.sha256((password or "").encode("utf-8")).hexdigest()
        if stored == legacy:
            if password:
                db.execute("UPDATE users SET password = ? WHERE id = ?", (generate_password_hash(password), user["id"]))
                db.commit()
            return db.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone()
        try:
            if check_password_hash(stored, password or ""):
                return user
        except (ValueError, TypeError):
            pass
        return None
    finally:
        db.close()
