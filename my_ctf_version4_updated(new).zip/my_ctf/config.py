import os
import secrets

CTF_DURATION = int(os.environ.get("CTF_DURATION_SECONDS", str(6 * 60 * 60)))
EASY_UNLOCK_SECONDS = int(os.environ.get("EASY_UNLOCK_SECONDS", str(5 * 60)))
MODERATE_UNLOCK_SECONDS = int(os.environ.get("MODERATE_UNLOCK_SECONDS", str(20 * 60)))
HARD_UNLOCK_SECONDS = int(os.environ.get("HARD_UNLOCK_SECONDS", str(20 * 60)))
DATABASE = os.environ.get("CTF_DATABASE_PATH", "data/ctf.db")
# Set CTF_SECRET_KEY to a long random value before deployment. A generated fallback is suitable only for local use.
SECRET_KEY = os.environ.get("CTF_SECRET_KEY") or secrets.token_hex(32)
