const elapsedAtLoad = Number(
    document.body.dataset.elapsed || 0
);

const duration = Number(
    document.body.dataset.duration || 21600
);

let remaining = duration - elapsedAtLoad;

function updateTimer() {

    const timer = document.getElementById("timer");

    if (!timer) {
        return;
    }

    if (remaining < 0) {
        remaining = 0;
    }

    const hours = Math.floor(
        remaining / 3600
    );

    const minutes = Math.floor(
        (remaining % 3600) / 60
    );

    const seconds = remaining % 60;

    timer.textContent =
        String(hours).padStart(2, "0") +
        ":" +
        String(minutes).padStart(2, "0") +
        ":" +
        String(seconds).padStart(2, "0");

    if (remaining === 0) {

        timer.classList.add(
            "expired"
        );

        return;
    }

    remaining--;
}

setInterval(
    updateTimer,
    1000
);

updateTimer();

