"""Basic HTTP load test for a locally running CTF instance.
Usage: python performance_test.py --url http://127.0.0.1:5000 --levels 25 50 100 200 --requests-per-user 10
Only test systems you own or have permission to test. This tests the login and scoreboard endpoints.
"""
import argparse, concurrent.futures, json, statistics, time, urllib.request, urllib.error, urllib.parse, os
try:
    import psutil
except ImportError:
    psutil = None

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--url',default='http://127.0.0.1:5000')
    parser.add_argument('--levels',nargs='+',type=int,default=[25,50,100,200])
    parser.add_argument('--requests-per-user',type=int,default=10)
    parser.add_argument('--timeout',type=float,default=10)
    args=parser.parse_args(); base=args.url.rstrip('/')
    def request_one(_):
        start=time.perf_counter(); status=0
        try:
            req=urllib.request.Request(base+'/scoreboard',headers={'User-Agent':'CTF-load-test/3.0'})
            with urllib.request.urlopen(req,timeout=args.timeout) as response: status=response.status; response.read()
        except urllib.error.HTTPError as e: status=e.code
        except Exception: status=-1
        return (time.perf_counter()-start)*1000, status
    print('target, concurrency, requests, errors, p50_ms, p95_ms, max_ms, cpu_before_percent, cpu_after_percent')
    for level in args.levels:
        if level < 1: continue
        cpu_before=psutil.cpu_percent(interval=.2) if psutil else 'n/a'
        tasks=level*args.requests_per_user; latencies=[]; errors=0; started=time.perf_counter()
        with concurrent.futures.ThreadPoolExecutor(max_workers=level) as pool:
            for latency,status in pool.map(request_one,range(tasks)):
                latencies.append(latency)
                if status < 200 or status >= 400: errors+=1
        elapsed=time.perf_counter()-started
        cpu_after=psutil.cpu_percent(interval=.2) if psutil else 'n/a'
        latencies.sort()
        def pct(p): return round(latencies[min(len(latencies)-1,int((len(latencies)-1)*p))],2) if latencies else 0
        print(f'{base},{level},{tasks},{errors},{pct(.50)},{pct(.95)},{round(max(latencies,default=0),2)},{cpu_before},{cpu_after}')
        print(f'  throughput={tasks/elapsed:.2f} requests/sec; elapsed={elapsed:.2f}s')
    print('Note: CPU figures are host-wide snapshots, not process-only measurements. Install psutil for CPU metrics. This script does not emulate authenticated flag bursts or multiple browser sessions.')
if __name__=='__main__': main()
