"""Create the first administrator securely (interactive; no hard-coded password)."""
import getpass
from database import init_db, get_db
from auth import create_user

init_db()
db = get_db()
existing = db.execute("SELECT COUNT(*) FROM users WHERE is_admin = 1").fetchone()[0]
db.close()
if existing:
    print("An administrator already exists. Use the admin panel to manage participants.")
    raise SystemExit(0)
username = input("New administrator username: ").strip()
password = getpass.getpass("New administrator password (minimum 12 characters recommended): ")
confirm = getpass.getpass("Confirm password: ")
if password != confirm:
    print("Passwords do not match.")
    raise SystemExit(1)
if len(password) < 12:
    print("Use a password with at least 12 characters.")
    raise SystemExit(1)
if create_user(username, password, is_admin=True):
    print("Administrator created. Keep the credentials private.")
else:
    print("Could not create administrator. Check username length and whether it already exists.")
    raise SystemExit(1)
