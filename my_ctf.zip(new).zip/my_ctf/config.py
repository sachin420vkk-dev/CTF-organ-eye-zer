CTF_DURATION = 6 * 60 * 60

# Round 3 unlocks after 1 hour 30 minutes (5400 seconds)
HARD_UNLOCK_SECONDS = 90 * 60

DATABASE = "data/ctf.db"

SECRET_KEY = "change-this-to-a-long-random-secret"

