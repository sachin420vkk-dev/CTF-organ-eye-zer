from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash
)

from datetime import datetime, timezone

from config import (
    SECRET_KEY,
    CTF_DURATION,
    HARD_UNLOCK_SECONDS
)

from database import get_db, init_db

from auth import (
    create_user,
    authenticate
)

from challenges import CHALLENGES


app = Flask(__name__)

app.secret_key = SECRET_KEY


# --------------------------------------------------
# DATABASE
# --------------------------------------------------

init_db()


# --------------------------------------------------
# USER
# --------------------------------------------------

def current_user():

    if "user_id" not in session:
        return None

    db = get_db()

    user = db.execute(
        """
        SELECT *
        FROM users
        WHERE id = ?
        """,
        (session["user_id"],)
    ).fetchone()

    db.close()

    return user


# --------------------------------------------------
# EVENT TIME
# --------------------------------------------------

def get_start_time():

    db = get_db()

    event = db.execute(
        """
        SELECT started_at
        FROM event
        WHERE id = 1
        """
    ).fetchone()

    db.close()

    if not event:
        return None

    if not event["started_at"]:
        return None

    return datetime.fromisoformat(
        event["started_at"]
    )


def elapsed_seconds():

    started = get_start_time()

    if not started:
        return 0

    now = datetime.now(timezone.utc)

    return max(
        0,
        int(
            (now - started).total_seconds()
        )
    )


def event_started():

    return get_start_time() is not None


def event_finished():

    return elapsed_seconds() >= CTF_DURATION


def hard_unlocked():

    return elapsed_seconds() >= HARD_UNLOCK_SECONDS


# --------------------------------------------------
# TEMPLATE VARIABLES
# --------------------------------------------------

@app.context_processor
def template_variables():

    return {

        "event_started":
            event_started(),

        "event_finished":
            event_finished(),

        "elapsed":
            elapsed_seconds(),

        "duration":
            CTF_DURATION,

        "hard_unlocked":
            hard_unlocked(),

        "hard_unlock_seconds":
            HARD_UNLOCK_SECONDS,

        "viewer":
            current_user()
    }


# --------------------------------------------------
# HOME
# --------------------------------------------------

@app.route("/")
def home():

    if "user_id" not in session:
        return redirect(
            url_for("login")
        )

    return redirect(
        url_for("dashboard")
    )


# --------------------------------------------------
# REGISTER
# --------------------------------------------------

@app.route(
    "/register",
    methods=["GET", "POST"]
)
def register():

    if request.method == "POST":

        username = request.form.get(
            "username",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        )

        if len(username) < 3:

            flash(
                "Username must be at least 3 characters."
            )

            return redirect(
                url_for("register")
            )

        if len(password) < 6:

            flash(
                "Password must be at least 6 characters."
            )

            return redirect(
                url_for("register")
            )

        success = create_user(
            username,
            password
        )

        if not success:

            flash(
                "Username already exists."
            )

            return redirect(
                url_for("register")
            )

        flash(
            "Registration successful."
        )

        return redirect(
            url_for("login")
        )

    return render_template(
        "register.html"
    )


# --------------------------------------------------
# LOGIN
# --------------------------------------------------

@app.route(
    "/login",
    methods=["GET", "POST"]
)
def login():

    if request.method == "POST":

        username = request.form.get(
            "username",
            ""
        ).strip()

        password = request.form.get(
            "password",
            ""
        )

        user = authenticate(
            username,
            password
        )

        if not user:

            flash(
                "Invalid username or password."
            )

            return redirect(
                url_for("login")
            )

        session.clear()

        session["user_id"] = user["id"]

        return redirect(
            url_for("dashboard")
        )

    return render_template(
        "login.html"
    )


# --------------------------------------------------
# LOGOUT
# --------------------------------------------------

@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("login")
    )


# --------------------------------------------------
# DASHBOARD
# --------------------------------------------------

@app.route("/dashboard")
def dashboard():

    user = current_user()

    if not user:

        return redirect(
            url_for("login")
        )

    db = get_db()

    solved_rows = db.execute(
        """
        SELECT challenge_id
        FROM submissions

        WHERE user_id = ?
        AND correct = 1
        """,
        (user["id"],)
    ).fetchall()

    db.close()

    solved = {
        row["challenge_id"]
        for row in solved_rows
    }

    sections = {
        1: [],
        2: [],
        3: []
    }

    for challenge in CHALLENGES:

        sections[
            challenge["section"]
        ].append(challenge)

    score = 0

    for challenge in CHALLENGES:

        if challenge["id"] in solved:

            score += challenge["points"]

    return render_template(
        "dashboard.html",

        user=user,

        sections=sections,

        solved=solved,

        score=score
    )


# --------------------------------------------------
# CHALLENGE
# --------------------------------------------------

@app.route(
    "/challenge/<int:challenge_id>",
    methods=["GET", "POST"]
)
def challenge(challenge_id):

    user = current_user()

    if not user:

        return redirect(
            url_for("login")
        )

    challenge_data = next(
        (
            c for c in CHALLENGES
            if c["id"] == challenge_id
        ),
        None
    )

    if not challenge_data:

        return "Challenge not found", 404

    # Allow participants/organizers to VIEW questions before the event starts.
    # Flag submissions still require the CTF to be running.
    if not event_started() and request.method == "POST":

        flash(
            "The CTF has not started yet. You can view the question, but submissions open when the admin starts the CTF."
        )

        return redirect(
            url_for("challenge", challenge_id=challenge_id)
        )

    if event_started() and event_finished():

        flash(
            "The CTF has ended."
        )

        return redirect(
            url_for("dashboard")
        )

    if (
        challenge_data["section"] == 3
        and not hard_unlocked()
    ):

        flash(
            "Section 3 is still locked."
        )

        return redirect(
            url_for("dashboard")
        )

    db = get_db()

    previous = db.execute(
        """
        SELECT *
        FROM submissions

        WHERE user_id = ?
        AND challenge_id = ?
        """,

        (
            user["id"],
            challenge_id
        )
    ).fetchone()

    if request.method == "POST":

        flag = request.form.get(
            "flag",
            ""
        ).strip()

        correct = (
            flag == challenge_data["answer"]
        )

        db.execute(
            """
            INSERT INTO submissions
            (
                user_id,
                challenge_id,
                correct,
                submitted_at
            )

            VALUES (?, ?, ?, datetime('now'))

            ON CONFLICT(user_id, challenge_id)

            DO UPDATE SET
                correct = excluded.correct,
                submitted_at = excluded.submitted_at
            """,

            (
                user["id"],
                challenge_id,
                int(correct)
            )
        )

        db.commit()

        db.close()

        if correct:

            flash(
                f"Correct! +{challenge_data['points']} points."
            )

        else:

            flash(
                "Incorrect flag."
            )

        return redirect(
            url_for(
                "challenge",
                challenge_id=challenge_id
            )
        )

    db.close()

    solved = (
        previous is not None
        and previous["correct"] == 1
    )

    return render_template(
        "challenge.html",

        challenge=challenge_data,

        solved=solved
    )


# --------------------------------------------------
# SCOREBOARD
# --------------------------------------------------

@app.route("/scoreboard")
def scoreboard():

    db = get_db()

    rows = db.execute(
        """
        SELECT
            users.username,

            SUM(
                CASE
                    WHEN submissions.correct = 1
                    THEN submissions_points.points
                    ELSE 0
                END
            ) AS score,

            COUNT(
                CASE
                    WHEN submissions.correct = 1
                    THEN 1
                END
            ) AS solved

        FROM users

        LEFT JOIN submissions
            ON users.id = submissions.user_id

        LEFT JOIN (
            SELECT 1 AS id, 100 AS points
            UNION ALL SELECT 2, 100
            UNION ALL SELECT 3, 100
            UNION ALL SELECT 4, 200
            UNION ALL SELECT 5, 200
            UNION ALL SELECT 6, 200
            UNION ALL SELECT 7, 200
            UNION ALL SELECT 8, 200
            UNION ALL SELECT 9, 400
            UNION ALL SELECT 10, 400
            UNION ALL SELECT 11, 400
            UNION ALL SELECT 12, 400
            UNION ALL SELECT 13, 400
        ) AS submissions_points

        ON submissions.challenge_id =
           submissions_points.id

        WHERE users.is_admin = 0

        GROUP BY users.id

        ORDER BY
            score DESC,
            solved DESC,
            users.username ASC
        """
    ).fetchall()

    db.close()

    return render_template(
        "scoreboard.html",
        rows=rows
    )


# --------------------------------------------------
# ADMIN
# --------------------------------------------------

@app.route("/admin")
def admin():

    user = current_user()

    if not user or not user["is_admin"]:

        return "Access denied", 403

    return render_template(
        "admin.html"
    )


@app.route(
    "/admin/start",
    methods=["POST"]
)
def admin_start():

    user = current_user()

    if not user or not user["is_admin"]:

        return "Access denied", 403

    db = get_db()

    event = db.execute(
        """
        SELECT started_at
        FROM event
        WHERE id = 1
        """
    ).fetchone()

    if event["started_at"]:

        flash(
            "The CTF has already started."
        )

    else:

        db.execute(
            """
            UPDATE event

            SET started_at = ?

            WHERE id = 1
            """,

            (
                datetime.now(
                    timezone.utc
                ).isoformat(),
            )
        )

        db.commit()

        flash(
            "CTF started!"
        )

    db.close()

    return redirect(
        url_for("admin")
    )


@app.route(
    "/admin/reset",
    methods=["POST"]
)
def admin_reset():

    user = current_user()

    if not user or not user["is_admin"]:

        return "Access denied", 403

    db = get_db()

    db.execute(
        "DELETE FROM submissions"
    )

    db.execute(
        """
        UPDATE event

        SET started_at = NULL

        WHERE id = 1
        """
    )

    db.commit()
    db.close()

    flash(
        "CTF reset successfully."
    )

    return redirect(
        url_for("admin")
    )


# --------------------------------------------------
# RUN
# --------------------------------------------------

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False
    )

