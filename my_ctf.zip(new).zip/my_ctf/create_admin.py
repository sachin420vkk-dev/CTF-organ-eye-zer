"""Create the local CTF administrator account.

Run:
    python create_admin.py

Default local credentials:
    Username: admin
    Password: admin123

Change the password in a real deployment.
"""
from auth import create_user
from database import init_db

init_db()

username = "admin"
password = "admin123"

if create_user(username, password, is_admin=True):
    print("Admin created successfully.")
    print("Username: admin")
    print("Password: admin123")
else:
    print("Admin could not be created. It may already exist.")
