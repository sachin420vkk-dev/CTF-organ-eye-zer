import sqlite3
import os

from config import DATABASE


def get_db():
    os.makedirs("data", exist_ok=True)

    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row

    return connection


def init_db():

    db = get_db()

    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER NOT NULL,
        challenge_id INTEGER NOT NULL,

        correct INTEGER NOT NULL DEFAULT 0,

        submitted_at TEXT NOT NULL,

        UNIQUE(user_id, challenge_id),

        FOREIGN KEY(user_id)
            REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS event (
        id INTEGER PRIMARY KEY CHECK(id = 1),

        started_at TEXT
    );

    INSERT OR IGNORE INTO event(id, started_at)
    VALUES(1, NULL);
    """)

    db.commit()
    db.close()

