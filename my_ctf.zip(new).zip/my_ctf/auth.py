import hashlib

from database import get_db


def hash_password(password):

    return hashlib.sha256(
        password.encode("utf-8")
    ).hexdigest()


def create_user(username, password, is_admin=False):

    db = get_db()

    try:

        db.execute(
            """
            INSERT INTO users
            (username, password, is_admin, created_at)

            VALUES (?, ?, ?, datetime('now'))
            """,

            (
                username,
                hash_password(password),
                int(is_admin)
            )
        )

        db.commit()

        return True

    except Exception:

        return False

    finally:

        db.close()


def authenticate(username, password):

    db = get_db()

    user = db.execute(
        """
        SELECT *
        FROM users

        WHERE username = ?
        AND password = ?
        """,

        (
            username,
            hash_password(password)
        )
    ).fetchone()

    db.close()

    return user

