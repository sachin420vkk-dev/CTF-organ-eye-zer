# IEEE × Graphic Era Hill University — CTF Platform

A local Flask-based Capture The Flag platform with a classic navy, cream and gold IEEE/GEHU visual theme.

## Included
- 13 challenges: 3 Easy, 5 Moderate, 5 Hard
- 6-hour CTF timer
- Round 3 / Hard unlocks after **1 hour 30 minutes**
- Registration and login
- SQLite scoreboard
- Admin start/reset controls
- IEEE and Graphic Era Hill University branding
- Shared cinematic mountain background and watermark treatment across the website

## Run locally

```bash
python -m venv venv
```

### Windows
```bash
venv\\Scripts\\activate
```

### Linux / macOS
```bash
source venv/bin/activate
```

Install Flask:
```bash
pip install -r requirements.txt
```

Create the admin account:
```bash
python create_admin.py
```

Default admin credentials:
- Username: `admin`
- Password: `admin123`

Start the platform:
```bash
python app.py
```

Open:
`http://127.0.0.1:5000`

## Event flow
1. Register a player account.
2. Log in.
3. Admin logs in with the admin account.
4. Open `/admin` and click **START CTF**.
5. Round 1 and Round 2 are available immediately.
6. Round 3 unlocks automatically after **01:30:00** from the event start.
7. The complete event ends after 6 hours.

Questions can be viewed before the event starts; flag submissions open only after the CTF starts.

## Note
The 13 challenge definitions are included in `challenges.py`. Some challenge descriptions refer to supplied lab artifacts such as PCAPs or binaries; those separate artifacts are not included in this basic platform ZIP.
